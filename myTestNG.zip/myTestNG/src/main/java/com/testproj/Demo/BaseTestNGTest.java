package com.testproj.Demo;

import org.testng.annotations.Configuration;


public class BaseTestNGTest {
}
