/**
 * Created by zhoulvming on 2017/6/10.
 */
public class Dataset {
    private String rowNo;
    private String rangeStart;
    private String rangeEnd;
    private String subcode;
    private String sequenceNo;

    public Dataset(String rowNo, String rangeStart, String rangeEnd, String subcode, String sequenceNo) {
        this.rowNo = rowNo;
        this.rangeStart = rangeStart;
        this.rangeEnd = rangeEnd;
        this.subcode = subcode;
        this.sequenceNo = sequenceNo;
    }

    public String getRowNo() {
        return rowNo;
    }

    public void setRowNo(String rowNo) {
        this.rowNo = rowNo;
    }

    public String getRangeStart() {
        return rangeStart;
    }

    public void setRangeStart(String rangeStart) {
        this.rangeStart = rangeStart;
    }

    public String getRangeEnd() {
        return rangeEnd;
    }

    public void setRangeEnd(String rangeEnd) {
        this.rangeEnd = rangeEnd;
    }

    public String getSubcode() {
        return subcode;
    }

    public void setSubcode(String subcode) {
        this.subcode = subcode;
    }

    public String getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(String sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    // 返回打印用
    @Override
    public String toString() {
        return rowNo + "|" + rangeStart + "|" + rangeEnd + "|" + subcode + "|" + sequenceNo + "\n";
    }
}
