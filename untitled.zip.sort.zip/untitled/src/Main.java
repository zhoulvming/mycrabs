import java.util.*;

public class Main {

    public static void main(String[] args) {
        
        List<Dataset> resultData = new ArrayList<Dataset>();
        List<Dataset> originalData = new ArrayList<Dataset>();
        boolean validFlag = true;

        Dataset ds = null;
        ds = new Dataset("1", "100", "99999", "SH1", "20000");
        originalData.add(ds);

        ds = new Dataset("2", "", "", "SH1", "10001");
        originalData.add(ds);

        ds = new Dataset("3", "", "", "RC2", "14001");
        originalData.add(ds);

        ds = new Dataset("4", "", "", "SW1", "10001");
        originalData.add(ds);

        ds = new Dataset("5", "", "", "RC2", "10002");
        originalData.add(ds);

        ds = new Dataset("6", "", "", "SH1", "13001");
        originalData.add(ds);

        ds = new Dataset("7", "", "", "SW1", "20001");
        originalData.add(ds);

        ds = new Dataset("8", "", "", "RC2", "10001");
        originalData.add(ds);

        if (resetData(originalData, resultData)) {
            System.out.println(originalData);
            System.out.println(resultData);
        } else {
            System.out.println("data error");
        }

    }

    private static boolean resetData(List<Dataset> originalData, List<Dataset> resultData) {
        SortListUtil<Dataset> lstUtil = new SortListUtil<Dataset>();
        boolean validFlag = true;
        if (resultData == null) {
            resultData = new ArrayList<Dataset>();
        }

        // step 1 : group by subcode
        lstUtil.sortByMethod(originalData, "getSubcode", false);
        Map<String, List<Dataset>> groupMap = new HashMap<String, List<Dataset>>();
        for (int i = 0; i < originalData.size(); i++) {
            Dataset data = (Dataset) originalData.get(i);
            String subcode = data.getSubcode();

            if (groupMap.containsKey(subcode)) {
                List<Dataset> lst = groupMap.get(subcode);
                lst.add(data);
            } else {
                List<Dataset> lst = new ArrayList<Dataset>();
                lst.add(data);
                groupMap.put(subcode, lst);
            }
        }

        // step2: sub group sort
        for (Map.Entry<String, List<Dataset>> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            List<Dataset> subLst = entry.getValue();
            lstUtil.sortByMethod(subLst, "getSequenceNo", false);

            // verify other squenceNo in rangeStart and rangeEnd
            List<String[]> lstRange = new ArrayList<String[]>();
            for(int i=0; i<subLst.size(); i++) {
                Dataset item = subLst.get(i);
                String rangeStart = item.getRangeStart();
                String rangeEnd = item.getRangeEnd();
                if (!rangeStart.equals("") && !rangeEnd.equals("")) {
                    lstRange.add(new String[]{item.getRangeStart(), item.getRangeEnd()});
                }
                resultData.add(item);
            }
            for(int i=0; i<subLst.size(); i++) {
                Dataset item = subLst.get(i);
                if (item.getSequenceNo().equals("")) {
                    continue;
                }
                for(int j=0; j<lstRange.size(); j++) {
                    String[] rangeAry = lstRange.get(j);
                    int rangeS = Integer.parseInt(rangeAry[0]);
                    int rangeE = Integer.parseInt(rangeAry[1]);
                    int sequenceNo = Integer.parseInt(item.getSequenceNo());
                    if ( rangeS < sequenceNo && sequenceNo < rangeE) {
                        validFlag = false;
                        break;
                    }
                }
                if (!validFlag) {
                    break;
                }
            }
        }

        if (!validFlag) {
            return false;
        }
        return true;
    }
}
