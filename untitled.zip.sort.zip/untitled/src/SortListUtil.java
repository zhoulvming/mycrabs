import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Created by zhoulvming on 2017/6/10.
 */
public class SortListUtil<E> {

    /**
     * sort list by get method name
     * @param list
     * @param method
     * @param reverseFlag
     */
    public void sortByMethod(List<E> list, final String method, final boolean reverseFlag) {

        Collections.sort(list, new Comparator<Object>() {

            @SuppressWarnings("unchecked")
            public int compare(Object arg1, Object arg2) {
                int result = 0;
                try {
                    Method m1 = ((E) arg1).getClass().getMethod(method, null);
                    Method m2 = ((E) arg2).getClass().getMethod(method, null);
                    Object obj1 = m1.invoke(((E)arg1), null);
                    Object obj2 = m2.invoke(((E)arg2), null);

                    if(obj1 instanceof String) {
                        result = obj1.toString().compareTo(obj2.toString());
                    }else if(obj1 instanceof Date) {
                        long l = ((Date)obj1).getTime() - ((Date)obj2).getTime();
                        if(l > 0) {
                            result = 1;
                        } else if(l < 0) {
                            result = -1;
                        } else {
                            result = 0;
                        }
                    }else if(obj1 instanceof Integer) {
                        result = (Integer)obj1 - (Integer)obj2;
                    }else {
                        result = obj1.toString().compareTo(obj2.toString());
                        System.err.println("unknown type");
                    }

                    if (reverseFlag) {
                        result = -result;
                    }
                } catch (NoSuchMethodException nsme) {
                    nsme.printStackTrace();
                } catch (IllegalAccessException iae) {
                    iae.printStackTrace();
                } catch (InvocationTargetException ite) {
                    ite.printStackTrace();
                }

                return result;
            }
        });

    }
}
