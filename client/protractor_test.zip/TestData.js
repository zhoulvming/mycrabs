(function(){
  exports.urls = {
    AngularJSURL: 'http://localhost:4200'
  }
})()